package questao1;

public class dadosmercados {

	public int id_preco;
	public int nu_prazo;
	public double vl_preco;
	
	
	public dadosmercados(int id_preco, int nu_prazo, double vl_preco) {
		this.id_preco = id_preco;
		this.nu_prazo = nu_prazo;
		this.vl_preco = vl_preco;
	}
	public int getId_preco() {
		return id_preco;
	}
	public void setId_preco(int id_preco) {
		this.id_preco = id_preco;
	}
	public int getNu_prazo() {
		return nu_prazo;
	}
	public void setNu_prazo(int nu_prazo) {
		this.nu_prazo = nu_prazo;
	}
	public double getVl_preco() {
		return vl_preco;
	}
	public void setVl_preco(double vl_preco) {
		this.vl_preco = vl_preco;
	}
	

}
