package questao1;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;



public class Lendoarq {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        List<dadosmercados> list = new ArrayList<>();

        List<Operacoes> lista = new ArrayList<>();

//		____________________________________________________

        System.out.println("Enter file path: ");

        String pathOfDadosmercados = "C:\\Users\\Tom Junior\\Desktop\\arquivoscsv\\DadosMercado.csv";

        System.out.println("Enter file path: ");
        String pathOfOperacoes = "C:\\Users\\Tom Junior\\Desktop\\arquivoscsv\\Operacoes.csv";


        File sourceFile = new File(pathOfDadosmercados);

        String resultFile = "C:\\Users\\Tom Junior\\Desktop\\arquivoscsv\\out\\result.csv";

        try (BufferedReader br = new BufferedReader(new FileReader(pathOfDadosmercados))) {

            String itemCsv = br.readLine();
            System.out.println("first = " + itemCsv);
            itemCsv = br.readLine();
            System.out.println("second  = " + itemCsv);
//            System.exit(0);

            while (itemCsv != null) {

                itemCsv = itemCsv.replace(",", ".");

                String[] fields = itemCsv.split(";");
                int id_preco2 = Integer.parseInt(fields[0]);
                int nu_prazo = Integer.parseInt(fields[1]);
                double vl_preco = Double.parseDouble(fields[2]);

                list.add(new dadosmercados(id_preco2, nu_prazo, vl_preco));
                itemCsv = br.readLine();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        try (BufferedReader br = new BufferedReader(new FileReader(pathOfOperacoes))) {
            String itemCsv1 = br.readLine();
            System.out.println("first = " + itemCsv1);

            itemCsv1 = br.readLine();
            System.out.println("second  = " + itemCsv1);
//            System.exit(0);

            while (itemCsv1 != null) {

                itemCsv1 = itemCsv1.replace(",", ".");

                String[] campos = itemCsv1.split(";");

                int cd_operacao = Integer.parseInt(campos[0]);

                String dt_inicio = campos[1];

                String dt_final = campos[2];

                String nm_empresa = campos[3];

                String nm_mesa = campos[4];

                String nm_estrategia = campos[5];

                String nm_centralizador = campos[6];

                String nm_gestor = campos[7];

                String nm_subgestor = campos[8];

                String nm_subproduto = campos[9];

                String nm_caracteristica = campos[10];

                String cd_ativo_obj = campos[11];

                double quantidade = Double.parseDouble(campos[12]);

                int id_preco1 = Integer.parseInt(campos[13]);

                lista.add(new Operacoes(cd_operacao, dt_inicio, dt_final, nm_empresa, nm_mesa, nm_estrategia, nm_centralizador, nm_gestor, nm_subgestor, nm_subproduto, nm_caracteristica, cd_ativo_obj, quantidade, id_preco1));
                itemCsv1 = br.readLine();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(resultFile))) {
        	for(dadosmercados dt : list) {
        		for(Operacoes op :lista ) {
        			if(op.getID_PRECO()==dt.id_preco) {
                    String stringToWrite = op.NM_SUBPRODUTO + ";" + String.format("\n"+"%f", dt.vl_preco * op.qtd());
                    bw.write(stringToWrite);
                    bw.flush();
                
               System.out.println(resultFile + " FEITO!!!");	
               long tempoInicio = System.currentTimeMillis();
               System.out.println((System.currentTimeMillis()-tempoInicio)); 
               break;               
               
        	} 
        			  
        	}
        		
        	}
        } catch (IOException e) {
            System.out.println("ERRO AO GRAVAR O ARQUIVO: " + e.getMessage());
            
            	
          	
        }     
        sc.close();
    }
    	
    		
    }

