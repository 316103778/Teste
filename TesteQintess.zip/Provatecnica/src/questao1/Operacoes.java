package questao1;


public class Operacoes {
	
 public int CD_OPERACAO;
 public String DT_INICIO;
 public String DT_FIM;
 public String NM_EMPRESA;
 public String NM_MESA;
 public String NM_ESTRATEGIA;
 public String NM_CENTRALIZADOR;
 public String NM_GESTOR;
 public String NM_SUBGESTOR;
 public String NM_SUBPRODUTO;
 public String NM_CARACTERISTICA;
 public String CD_ATIVO_OBJETO;
 public double QUANTIDADE;
 public int ID_PRECO;
 
 
 
public int getCD_OPERACAO() {
	return CD_OPERACAO;
}
public void setCD_OPERACAO(int cD_OPERACAO) {
	CD_OPERACAO = cD_OPERACAO;
}
public String getDT_INICIO() {
	return DT_INICIO;
}
public void setDT_INICIO(String dT_INICIO) {
	DT_INICIO = dT_INICIO;
}
public String getDT_FIM() {
	return DT_FIM;
}
public void setDT_FIM(String dT_FIM) {
	DT_FIM = dT_FIM;
}
public String getNM_EMPRESA() {
	return NM_EMPRESA;
}
public void setNM_EMPRESA(String nM_EMPRESA) {
	NM_EMPRESA = nM_EMPRESA;
}
public String getNM_MESA() {
	return NM_MESA;
}
public void setNM_MESA(String nM_MESA) {
	NM_MESA = nM_MESA;
}
public String getNM_ESTRATEGIA() {
	return NM_ESTRATEGIA;
}
public void setNM_ESTRATEGIA(String nM_ESTRATEGIA) {
	NM_ESTRATEGIA = nM_ESTRATEGIA;
}
public String getNM_CENTRALIZADOR() {
	return NM_CENTRALIZADOR;
}
public void setNM_CENTRALIZADOR(String nM_CENTRALIZADOR) {
	NM_CENTRALIZADOR = nM_CENTRALIZADOR;
}
public String getNM_GESTOR() {
	return NM_GESTOR;
}
public void setNM_GESTOR(String nM_GESTOR) {
	NM_GESTOR = nM_GESTOR;
}
public String getNM_SUBGESTOR() {
	return NM_SUBGESTOR;
}
public void setNM_SUBGESTOR(String nM_SUBGESTOR) {
	NM_SUBGESTOR = nM_SUBGESTOR;
}
public String getNM_SUBPRODUTO() {
	return NM_SUBPRODUTO;
}
public void setNM_SUBPRODUTO(String nM_SUBPRODUTO) {
	NM_SUBPRODUTO = nM_SUBPRODUTO;
}
public String getNM_CARACTERISTICA() {
	return NM_CARACTERISTICA;
}
public void setNM_CARACTERISTICA(String nM_CARACTERISTICA) {
	NM_CARACTERISTICA = nM_CARACTERISTICA;
}
public String getCD_ATIVO_OBJETO() {
	return CD_ATIVO_OBJETO;
}
public void setCD_ATIVO_OBJETO(String cD_ATIVO_OBJETO) {
	CD_ATIVO_OBJETO = cD_ATIVO_OBJETO;
}
public double getQUANTIDADE() {
	return QUANTIDADE;
}
public void setQUANTIDADE(double qUANTIDADE) {
	QUANTIDADE = qUANTIDADE;
}
public int getID_PRECO() {
	return ID_PRECO;
}
public void setID_PRECO(int iD_PRECO) {
	ID_PRECO = iD_PRECO;
}

public Operacoes(int cD_OPERACAO, String dT_INICIO, String dT_FIM, String nM_EMPRESA, String nM_MESA,
		String nM_ESTRATEGIA, String nM_CENTRALIZADOR, String nM_GESTOR, String nM_SUBGESTOR, String nM_SUBPRODUTO,
		String nM_CARACTERISTICA, String cD_ATIVO_OBJETO, double qUANTIDADE, int iD_PRECO) {
	super();
	CD_OPERACAO = cD_OPERACAO;
	DT_INICIO = dT_INICIO;
	DT_FIM = dT_FIM;
	NM_EMPRESA = nM_EMPRESA;
	NM_MESA = nM_MESA;
	NM_ESTRATEGIA = nM_ESTRATEGIA;
	NM_CENTRALIZADOR = nM_CENTRALIZADOR;
	NM_GESTOR = nM_GESTOR;
	NM_SUBGESTOR = nM_SUBGESTOR;
	NM_SUBPRODUTO = nM_SUBPRODUTO;
	NM_CARACTERISTICA = nM_CARACTERISTICA;
	CD_ATIVO_OBJETO = cD_ATIVO_OBJETO;
	QUANTIDADE = qUANTIDADE;
	ID_PRECO = iD_PRECO;
}
public double qtd() {
	return QUANTIDADE;
}
 
	
}